/**
 * Meteor Mongo Collection
 */

Chats = new Mongo.Collection("chats");
