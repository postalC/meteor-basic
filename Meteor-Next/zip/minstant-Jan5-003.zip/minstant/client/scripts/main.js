/**
 * Meteor Client JS
 */
Meteor.subscribe('usersData', function() {
  return Meteor.users.find().fetch();
});
Meteor.subscribe('chatDialog', function() {
  return Chats.find().fetch();
});
