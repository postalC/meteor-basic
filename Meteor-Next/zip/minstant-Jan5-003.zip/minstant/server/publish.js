// -- users data --
Meteor.publish("usersData", function() {
  return Meteor.users.find();
});

// -- chat dialog --
Meteor.publish("chatDialog", function() {
  return Chats.find({
    $or: [{
      user1Id: this.userId
    }, {
      user2Id: this.userId
    }]
  });
});
