/**
 * Meteor Client JS
 */
Meteor.subscribe('usersData');
Meteor.subscribe('chatDialog');
