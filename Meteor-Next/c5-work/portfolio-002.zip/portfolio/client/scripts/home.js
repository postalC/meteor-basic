// -- helper function for user login --
Template.home.helpers({
  loginUser: function() {
    return Meteor.users.findOne({
      _id: Meteor.userId()
    });
  },
});
