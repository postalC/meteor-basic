// -- helper function for websites lists - top 5 - in landing_page --
Template.landingpage.helpers({
  topfive: function() {
    return Websites.find({}, {
      skip: 0,
      limit: 5
    });
  }
});
