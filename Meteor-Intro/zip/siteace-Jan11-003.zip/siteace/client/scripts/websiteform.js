/**
 * Meteor Client Website Form Template JS
 */

// -- Events --
Template.websiteform.events({
  "click .js-website-modal": function(event) {
    $("#addModal").modal("show");
  },
  "submit .js-website-save": function(event) {

    // here is an example of how to get the url out of the form:
    var url = event.target.url.value;
    console.log("The url they entered is: " + url);

    //  put your website saving code in here!

    return false; // stop the form submit from reloading the page

  }
});
