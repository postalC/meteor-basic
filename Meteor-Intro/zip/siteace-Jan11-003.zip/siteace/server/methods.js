/**
 * Meteor Methods JS
 */
Meteor.methods({

});
