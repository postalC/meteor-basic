// -- helper function for user login --
Template.lobby_page.helpers({
  loginUser: function() {
    return Meteor.users.findOne({
      _id: Meteor.userId()
    });
  },
});
