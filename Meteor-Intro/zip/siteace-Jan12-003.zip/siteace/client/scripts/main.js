/**
 * Meteor Client JS
 */
// accounts config
Accounts.ui.config({
  passwordSignupFields: "USERNAME_AND_EMAIL"
});
///
